import './createBoard.css';
import React, { useState } from 'react';

export function CreateBoard({ n }) {
 
    
  const [board, setBoard] = useState(Array(n).fill().map(() => Array(n).fill(null)));
  let [xTurn, setXturn] = useState(true);
  
    const handleClick = (row, col) => {
    let newBoard = [...board]; 
    if(newBoard[row][col] == null){
        newBoard[row][col] = xTurn ? "X" : "O";
        setBoard(newBoard); 
        setXturn(!xTurn);
    }
    
    const winerr = checkWining(newBoard);
    
    let nullYes = false;
    board.forEach(arr => {
        arr.forEach(val => {
            if(val == null){
                nullYes = true;
            }           
        })
    })

    if(nullYes == false){
        setTimeout(() => {
            alert("Nobody Win");
            const newGame =  Array(n).fill().map(() => Array(n).fill(null));
            setXturn(true)
            newBoard = newGame;
            setBoard(newBoard); 
            nullYes = true;
        },100)
       
    }


    if(winerr !== null){
        setTimeout(() => {
            alert(winerr + " Winnnn")
            const newGame =  Array(n).fill().map(() => Array(n).fill(null));
            newBoard[row][col] = winerr
            setXturn(true)
            newBoard = newGame;
            setBoard(newBoard); 
       
        },100)  
        
    }

  };

  return (
    <div className="grid-container">
      {board.map((row, rowIndex) => (
        <div key={rowIndex} className="grid-row">
          {row.map((cell, colIndex) => (
            <div
              key={colIndex}
              className="grid-item"
              onClick={() => handleClick(rowIndex, colIndex)}
            >
              {cell !== null ? cell : ""}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function checkWining(board){
    
    for(let i = 0; i < board.length; i++){
        let winning = true;
        for(let j = 1; j < board.length; j++){
            if(board[i][j - 1] != board[i][j]){
                winning = false;
            }
        }
        if(winning == true && board[i][0] != null){
            return board[i][0];
        }else{
            winning = true;
        }
    }


    for(let i = 0; i < board.length; i++){
        let winning = true;
        for(let j = 1; j < board.length; j++){
            if(board[j - 1][i] != board[j][i]){
                winning = false;
            }
        }
        if(winning == true && board[0][i] != null){
            return board[0][i];
        }else{
            winning = true;
        }
    }   
    
    
    for(let i = 1, winning = true; i < board.length; i++){
        if(board[i - 1][i - 1] != board[i][i]){
            winning = false;
        }
        if(i == (board.length - 1)){
            if(winning == true && board[i][i] != null){
                return board[i][i];
            }
        }
    }

    for(let i = 0, j = board.length - 1, winning = true; i < board.length && j > 0; i++ , j--){
        if(board[j - 1][i + 1] !== board[j][i]){
            winning = false;
        }
        if(i === (board.length - 2)){
            if(winning === true && board[j][i] !== null){
                return board[j][i];
            }
        }
    }

   return null;

}

