import './App.css';
import { CreateBoard } from './createBoard';
import React, { useState } from 'react';

function App() {
  
  const BoardSize = 3;

  return (
    <div className="App">
      <div className='Title'>
        <h1>Tic-Tac-Toe</h1>
      </div>
      <div className='Board'>
        <CreateBoard n = {BoardSize}/>
      </div>      
    </div>
  );
}

export default App;
